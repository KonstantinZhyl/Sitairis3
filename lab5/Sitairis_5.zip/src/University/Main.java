package University;

import XMLsaxParser.SAXParserDemo;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        SAXParserDemo SaxParser = SAXParserDemo.Init();
        List<Student> group = SaxParser.parse("data.xml");
        for (Student s : group) {
            System.out.println(s + "\n");
        }
    }
}