package University;

public class Student {
    public String firstname;
    public String lastname;
    public boolean form;
    public int id;
    public int mathMark;
    public int physicsMark;
    public int russianMark;

    @Override
    public String toString() {
        String ans = firstname + " " + lastname + ", группа "
                + Integer.toString(id);
        if (form) {
            ans += " бюджетник\n";
        }
        else {
            ans += " платник\n";
        }
        ans += "Математика: " + Integer.toString(mathMark) + "\n";
        ans += "Физика: " + Integer.toString(physicsMark) + "\n";
        ans += "Русский: " + Integer.toString(russianMark);
        return ans;
    }
}
