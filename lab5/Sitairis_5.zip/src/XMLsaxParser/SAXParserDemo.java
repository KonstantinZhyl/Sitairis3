package XMLsaxParser;

import University.Student;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class SAXParserDemo {
    public List<Student> group;
    private static SAXParserDemo single_instance = null;

    public List<Student> parse(String filename) {
        group = new ArrayList<Student>();
        try {
            File inputFile = new File(filename);
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            MyHandler myhandler = new MyHandler(group);
            saxParser.parse(inputFile, myhandler);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return group;
    }

    private SAXParserDemo() {}

    public static SAXParserDemo Init()
    {
        if (single_instance == null)
            single_instance = new SAXParserDemo();

        return single_instance;
    }
}